'==============================================================================
' US Inflation Forecast with an Autoregressive (AR) Model - EViews program
' Author:  Michael Sillyman
' Data:    cpi_monthly.csv - CPI for All Urban Consumers (CPI-U), seasonally
'          adjusted, Index 1982-84=100. Source: U.S. Bureau of Labor Statistics,
'          via FRED series CPIAUCSL (St. Louis Fed). Jan 2014 - Sep 2026.
' Run:     Put this file and cpi_monthly.csv in one folder, open the program
'          in EViews (File > Open > Program), then click Run.
'          Written for EViews 10 or later.
'==============================================================================

' Workfile runs to Sep 2027 to leave room for the 12-month forecast
wfcreate(wf=cpi_forecast, page=monthly) m 2014m01 2027m09
import "cpi_monthly.csv" @freq m 2014m01

'------------------------------------------------------------------------------
' 1. Fill the Oct 2025 gap. BLS did not publish October 2025 CPI because of the
'    federal government shutdown. Use the geometric mean of Sep and Nov 2025.
'------------------------------------------------------------------------------
smpl @all
series cpi_f = cpi
smpl if cpi = na and cpi(-1) <> na and cpi(1) <> na
cpi_f = @sqrt(cpi(-1) * cpi(1))
smpl @all

series lcpi = log(cpi_f)                      ' log price level
series infl = 100 * dlog(cpi_f)               ' monthly inflation, % change
series yoy  = 100 * (cpi_f / cpi_f(-12) - 1)  ' year-over-year inflation, %

smpl 2014m01 2026m09
freeze(g_history) yoy.line
g_history.addtext(t) "US CPI inflation, year over year (%)"

'------------------------------------------------------------------------------
' 2. Stationarity: Augmented Dickey-Fuller tests (lag length by Schwarz)
'    Expect: log CPI has a unit root; monthly inflation does not.
'------------------------------------------------------------------------------
freeze(t_adf_lcpi) lcpi.uroot(adf, trend, info=sic, maxlag=12)
freeze(t_adf_infl) infl.uroot(adf, const, info=sic, maxlag=12)

'------------------------------------------------------------------------------
' 3. Model selection: AR(1) to AR(12) on a common sample
'------------------------------------------------------------------------------
smpl 2015m02 2026m09
matrix(12, 3) m_criteria
for !p = 1 to 12
  equation eq_ar!p.ls infl c infl(-1 to -!p)
  m_criteria(!p, 1) = !p
  m_criteria(!p, 2) = eq_ar!p.@aic
  m_criteria(!p, 3) = eq_ar!p.@schwarz
next
' Schwarz picks AR(1), Akaike picks AR(7). Check both for leftover autocorrelation:
freeze(t_q_ar1) eq_ar1.correl(12)
freeze(t_q_ar7) eq_ar7.correl(12)
' AR(1) residuals fail the Ljung-Box Q test; AR(7) residuals pass, so AR(7) is used.
' (EViews reports Q with 12 degrees of freedom here; the report uses 12 - p.
'  The conclusion is the same either way.)

'------------------------------------------------------------------------------
' 4. Holdout test: estimate to Sep 2024, forecast Oct 2024 - Sep 2026
'------------------------------------------------------------------------------
smpl 2014m01 2024m09
equation eq_train.ls infl c infl(-1 to -7)
scalar avg_last12 = @mean(infl, "2023m10 2024m09")

smpl 2024m10 2026m09
eq_train.forecast infl_hold                      ' dynamic multi-step forecast
series naive_last12 = avg_last12                 ' benchmark 1: last 12 months' average
series naive_2pct = 100 * log(1.02) / 12         ' benchmark 2: Fed's 2% target pace
scalar rmse_ar7    = @sqrt(@mean((infl - infl_hold)^2))
scalar rmse_last12 = @sqrt(@mean((infl - naive_last12)^2))
scalar rmse_2pct   = @sqrt(@mean((infl - naive_2pct)^2))

'------------------------------------------------------------------------------
' 5. Final model on the full sample, with diagnostics
'------------------------------------------------------------------------------
smpl 2014m01 2026m09
equation eq_final.ls infl c infl(-1 to -7)
freeze(t_final) eq_final.output
freeze(t_q_final) eq_final.correl(12)           ' residual autocorrelation (Ljung-Box Q)
freeze(t_normality) eq_final.hist               ' Jarque-Bera normality test

'------------------------------------------------------------------------------
' 6. Forecast Oct 2026 - Sep 2027 with 95% intervals
'------------------------------------------------------------------------------
smpl 2026m10 2027m09
eq_final.forecast infl_f infl_f_se
series infl_lo95 = infl_f - 1.96 * infl_f_se
series infl_hi95 = infl_f + 1.96 * infl_f_se

' Build the CPI path month by month, then year-over-year inflation
cpi_f = cpi_f(-1) * exp(infl_f / 100)
yoy = 100 * (cpi_f / cpi_f(-12) - 1)

smpl 2025m01 2027m09
freeze(g_forecast) yoy.line
g_forecast.addtext(t) "Year-over-year inflation: actual to Sep 2026, forecast to Sep 2027"

group g_fc_values infl_f infl_lo95 infl_hi95 cpi_f yoy
smpl 2026m10 2027m09
freeze(t_forecast) g_fc_values.sheet
smpl @all
wfsave cpi_forecast.wf1
