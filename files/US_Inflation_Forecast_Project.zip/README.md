# US Inflation Forecast (EViews)

**Author:** Michael Sillyman · **Tool:** EViews
**Data:** Consumer Price Index for All Urban Consumers (CPI-U), all items, seasonally adjusted, index 1982–84 = 100. Source: U.S. Bureau of Labor Statistics, via FRED series [CPIAUCSL](https://fred.stlouisfed.org/series/CPIAUCSL). Monthly, Jan 2014 – Sep 2026 (153 months).

## Question
Where is US consumer price inflation headed over the next 12 months (Oct 2026 – Sep 2027)?

## Method
1. **Data gap:** BLS did not publish October 2025 CPI because of the federal government shutdown. I filled it with the geometric mean of September and November 2025 (324.654).
2. **Stationarity:** Augmented Dickey-Fuller tests show log CPI has a unit root (τ = -1.50), while monthly inflation is stationary (τ = -6.48), so I modelled monthly inflation.
3. **Model choice:** the Schwarz criterion picks AR(1), but its residuals fail the Ljung-Box test (p = 0.005). The Akaike criterion picks AR(7), which passes (p = 0.245) and is stable, so I used AR(7).
4. **Holdout test:** fitted on data to Sep 2024 and forecast Oct 2024 – Sep 2026. Monthly RMSE: AR(7) 0.248, last-12-month average 0.253, 2% target pace 0.265.
5. **Forecast:** refitted on the full sample (R² = 0.39) and forecast 12 months ahead with 95% intervals.

## Forecast
| Month | Monthly inflation | CPI | Year over year | 95% range (YoY) |
|---|---|---|---|---|
| 2026-10 | 0.62% | 338.4 | 4.2% | 3.8% – 4.7% |
| 2026-11 | 0.35% | 339.6 | 4.5% | 3.6% – 5.4% |
| 2026-12 | 0.41% | 341.0 | 4.6% | 3.4% – 5.8% |
| 2027-01 | 0.22% | 341.7 | 4.6% | 3.2% – 6.1% |
| 2027-02 | 0.19% | 342.4 | 4.6% | 2.9% – 6.2% |
| 2027-03 | 0.30% | 343.4 | 4.0% | 2.1% – 5.9% |
| 2027-04 | 0.36% | 344.6 | 3.7% | 1.6% – 5.8% |
| 2027-05 | 0.42% | 346.1 | 3.6% | 1.3% – 6.0% |
| 2027-06 | 0.33% | 347.2 | 4.4% | 1.8% – 7.1% |
| 2027-07 | 0.32% | 348.3 | 4.7% | 1.7% – 7.7% |
| 2027-08 | 0.30% | 349.4 | 4.6% | 1.4% – 7.9% |
| 2027-09 | 0.27% | 350.3 | 4.2% | 0.7% – 7.7% |

Year-over-year inflation was 3.7% in September 2026. The model expects it to stay between 3.6% and 4.7% through September 2027, well above the Federal Reserve's 2% target.

## Limitations
- An AR model uses only past inflation. It ignores interest rates, oil prices and wages, and it cannot foresee shocks. In the holdout test it expected 2.8% inflation by Sep 2026; the actual figure was 3.7%.
- Residuals are not normally distributed (driven by the 2020–22 shocks), so the intervals are approximate.

## How to run
Put `forecast_cpi.prg` and `cpi_monthly.csv` in one folder, open the program in EViews (File > Open > Program) and click Run. It creates `cpi_forecast.wf1` with every test, equation, graph and forecast table saved as named objects (`t_adf_lcpi`, `m_criteria`, `eq_final`, `t_forecast`, `g_forecast` and more). Written for EViews 10 or later.

`model_forecast.py` reproduces every step independently in Python (NumPy/SciPy); the report's figures come from that run.

## Files
| File | Description |
|---|---|
| `US_Inflation_Forecast_Report.pdf` | One-page report |
| `forecast_cpi.prg` | EViews program for every step |
| `cpi_monthly.csv` | CPI data used (Oct 2025 left blank, as published) |
| `forecast.csv` | 12-month forecast with 95% intervals |
| `model_forecast.py` | Independent verification in Python |
