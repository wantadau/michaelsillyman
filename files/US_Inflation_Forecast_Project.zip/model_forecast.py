"""Inflation forecast: the same steps as forecast_cpi.prg (EViews), reproduced in NumPy/SciPy.

Steps
 1. Fill the Oct 2025 gap (no BLS release during the shutdown) by geometric interpolation.
 2. Inflation = 100 * dlog(CPI), the monthly % change.
 3. ADF unit-root tests on log CPI and on monthly inflation.
 4. Choose an AR(p) model for monthly inflation (p = 1..12): compare Schwarz (SIC) and Akaike (AIC) picks,
    keep the one whose residuals pass the Ljung-Box test for leftover autocorrelation.
 5. Holdout test: fit on Jan 2014 - Sep 2024, forecast Oct 2024 - Sep 2026, compare with naive benchmarks.
 6. Refit on the full sample, run diagnostics, forecast Oct 2026 - Sep 2027 with 95% intervals.
Writes results.json and forecast.csv.
"""
import json
import numpy as np
import pandas as pd
from scipy import stats

df = pd.read_csv("cpi_monthly.csv", parse_dates=["date"]).set_index("date")
gap = df.cpi.isna()
gap_dates = [d.strftime("%Y-%m") for d in df.index[gap]]
df["cpi_filled"] = np.exp(np.log(df.cpi).interpolate())          # geometric mean of neighbours
df["lcpi"] = np.log(df.cpi_filled)
df["infl"] = 100 * df.lcpi.diff()                                   # monthly % change
df["yoy"] = 100 * (df.cpi_filled / df.cpi_filled.shift(12) - 1)
R = {"gap": {d: df.loc[d + "-01", "cpi_filled"] for d in gap_dates}, "n_obs": len(df),
     "last_date": df.index[-1].strftime("%b %Y"), "last_cpi": df.cpi.iloc[-1], "last_yoy": df.yoy.iloc[-1]}


def ols(y, X):
    b, *_ = np.linalg.lstsq(X, y, rcond=None)
    e = y - X @ b
    n, k = X.shape
    s2 = e @ e / (n - k)
    se = np.sqrt(np.diag(s2 * np.linalg.inv(X.T @ X)))
    return b, se, e, s2


def adf(series, trend=False, maxlag=12):
    """ADF test, lag length by Schwarz criterion (EViews default). Returns stat, lag, 5% critical value."""
    y = series.dropna().values
    dy = np.diff(y)
    best = None
    for p in range(maxlag + 1):
        rows = range(maxlag, len(dy))                                # common sample across lag choices
        Y = dy[list(rows)]
        cols = [np.ones(len(Y)), y[list(rows)]]
        if trend:
            cols.append(np.arange(len(Y), dtype=float))
        for j in range(1, p + 1):
            cols.append(dy[[r - j for r in rows]])
        X = np.column_stack(cols)
        b, se, e, s2 = ols(Y, X)
        n = len(Y)
        sic = np.log(e @ e / n) + X.shape[1] * np.log(n) / n
        if best is None or sic < best[0]:
            best = (sic, p, b[1] / se[1], n)
    _, p, stat, n = best
    # MacKinnon (2010) response-surface 5% critical values
    if trend:
        cv5 = -3.41049 - 4.3904 / n - 9.036 / n ** 2
    else:
        cv5 = -2.86154 - 2.8903 / n - 4.234 / n ** 2
    return {"stat": stat, "lag": p, "cv5": cv5, "reject_unit_root": bool(stat < cv5)}


R["adf"] = {"log_cpi_trend": adf(df.lcpi, trend=True), "inflation": adf(df.infl, trend=False)}


def design(y, p, start, end):
    """Rows start..end (inclusive labels) of y regressed on a constant and p lags."""
    Y, X, idx = [], [], []
    for t in range(len(y)):
        d = y.index[t]
        if d < pd.Timestamp(start) or d > pd.Timestamp(end) or t < p:
            continue
        lags = [y.iloc[t - j] for j in range(1, p + 1)]
        if np.isnan(y.iloc[t]) or any(np.isnan(lags)):
            continue
        Y.append(y.iloc[t]); X.append([1.0] + lags); idx.append(d)
    return np.array(Y), np.array(X), idx


def select_p(y, start, end, pmax=12):
    out = {}
    for p in range(1, pmax + 1):
        # common estimation sample: start after the longest lag
        Y, X, _ = design(y, p, start, end)
        Y, X = Y[pmax - p:], X[pmax - p:]
        b, se, e, s2 = ols(Y, X)
        n = len(Y)
        out[p] = {"aic": np.log(e @ e / n) + 2 * (p + 1) / n, "sic": np.log(e @ e / n) + (p + 1) * np.log(n) / n}
    p_sic = min(out, key=lambda k: out[k]["sic"])
    p_aic = min(out, key=lambda k: out[k]["aic"])
    return p_sic, p_aic, out


def fit(y, p, start, end):
    Y, X, idx = design(y, p, start, end)
    b, se, e, s2 = ols(Y, X)
    return {"b": b, "se": se, "resid": pd.Series(e, index=idx), "s2": s2, "n": len(Y),
            "r2": 1 - (e @ e) / ((Y - Y.mean()) @ (Y - Y.mean()))}


def forecast(y_hist, model, h):
    """Dynamic h-step forecast with 95% intervals (psi-weight variance)."""
    b = model["b"]; p = len(b) - 1
    hist = list(y_hist.values[-p:])
    fc = []
    for _ in range(h):
        nxt = b[0] + sum(b[j] * hist[-j] for j in range(1, p + 1))
        fc.append(nxt); hist.append(nxt)
    psi = [1.0]
    for i in range(1, h):
        psi.append(sum(b[j] * psi[i - j] for j in range(1, p + 1) if i - j >= 0))
    se = np.sqrt(model["s2"] * np.cumsum(np.square(psi)))
    return np.array(fc), se


def ljung_box(e, p, lags=12):
    r = [np.corrcoef(e[k:], e[:-k])[0, 1] for k in range(1, lags + 1)]
    Q = len(e) * (len(e) + 2) * sum(rk ** 2 / (len(e) - k) for k, rk in enumerate(r, 1))
    return Q, float(stats.chi2.sf(Q, lags - p))


infl = df.infl
TRAIN_END, TEST_START, TEST_END = "2024-09-01", "2024-10-01", "2026-09-01"
# ---------------- Model choice (full sample) ----------------
p_sic, p_aic, crit = select_p(infl, "2014-02-01", TEST_END)
lb_sic = ljung_box(fit(infl, p_sic, "2014-02-01", TEST_END)["resid"].values, p_sic)
lb_aic = ljung_box(fit(infl, p_aic, "2014-02-01", TEST_END)["resid"].values, p_aic)
P = p_sic if lb_sic[1] >= .05 else p_aic
R["selection"] = {"p_sic": p_sic, "lb_p_sic": lb_sic[1], "p_aic": p_aic, "lb_p_aic": lb_aic[1], "chosen": P}

# ---------------- Holdout evaluation (same specification, training data only) ----------------
p_sic_tr = P
m_tr = fit(infl, P, "2014-02-01", TRAIN_END)
m_tr1 = fit(infl, 1, "2014-02-01", TRAIN_END)
test = infl[TEST_START:TEST_END]
fc_tr, _ = forecast(infl[:TRAIN_END], m_tr, len(test))
fc_tr1, _ = forecast(infl[:TRAIN_END], m_tr1, len(test))
naive_last12 = np.full(len(test), infl["2023-10-01":TRAIN_END].mean())   # last 12 months' average pace
naive_2pct = np.full(len(test), 100 * np.log(1.02) / 12)                  # Fed's 2% target pace


def acc(f):
    e = test.values - f
    return {"rmse": float(np.sqrt(np.mean(e ** 2))), "mae": float(np.mean(np.abs(e)))}


def yoy_path(fc, start_label):
    """Convert monthly % forecasts into CPI levels and year-over-year inflation."""
    lv = df.cpi_filled.copy()
    dates = pd.date_range(start_label, periods=len(fc), freq="MS")
    last = lv[:pd.Timestamp(start_label) - pd.offsets.MonthBegin(1)]
    levels = []
    prev = last.iloc[-1]
    for f in fc:
        prev = prev * np.exp(f / 100); levels.append(prev)
    s = pd.concat([last, pd.Series(levels, index=dates)])
    return s, 100 * (s / s.shift(12) - 1)


_, yoy_tr = yoy_path(fc_tr, TEST_START)
R["holdout"] = {
    "train": f"Feb 2014 - Sep 2024", "test": "Oct 2024 - Sep 2026", "p": p_sic_tr,
    "ar": acc(fc_tr), "ar1": acc(fc_tr1), "naive_last12": acc(naive_last12), "naive_2pct": acc(naive_2pct),
    "yoy_sep2026_actual": df.yoy[TEST_END], "yoy_sep2026_ar": yoy_tr[TEST_END],
    "yoy_sep2026_last12": float(100 * (np.exp(12 * naive_last12[0] / 100) - 1)),
}

# ---------------- Final model on the full sample ----------------
m = fit(infl, P, "2014-02-01", TEST_END)
e = m["resid"].values
Q, lbp = ljung_box(e, P)
jb = stats.jarque_bera(e)
tvals = m["b"] / m["se"]
pvals = 2 * stats.t.sf(np.abs(tvals), m["n"] - len(m["b"]))
roots = np.roots(np.r_[1, -m["b"][1:]])
R["model"] = {
    "p_sic": p_sic, "p_aic": p_aic, "n": m["n"], "r2": m["r2"], "se_reg": float(np.sqrt(m["s2"])),
    "coef": [{"name": "C" if i == 0 else f"INFL(-{i})", "b": m["b"][i], "se": m["se"][i], "t": tvals[i],
              "p": pvals[i]} for i in range(len(m["b"]))],
    "p": P, "ljung_box_Q12": Q, "ljung_box_p": lbp,
    "jarque_bera": jb.statistic, "jarque_bera_p": jb.pvalue,
    "max_inverse_root": float(np.max(np.abs(roots))) if len(roots) else 0.0,  # roots of z^p - b1 z^(p-1) - ... are the inverse roots
    "implied_long_run_annual": float(100 * (np.exp(12 * m["b"][0] / (1 - m["b"][1:].sum()) / 100) - 1)),
    "criteria": crit,
}

H = 12
fc, se = forecast(infl, m, H)
lv, yy = yoy_path(fc, "2026-10-01")
# Year-over-year interval: variance of the sum of monthly forecast errors over the horizon
b = m["b"]; pp = len(b) - 1
psi = [1.0]
for i in range(1, H):
    psi.append(sum(b[j] * psi[i - j] for j in range(1, pp + 1) if i - j >= 0))
cum_psi = np.cumsum(psi)                                 # effect of a shock on the cumulated log level
var_sum = [m["s2"] * np.sum(np.square(cum_psi[:k][::-1])) for k in range(1, H + 1)]
fdates = pd.date_range("2026-10-01", periods=H, freq="MS")
rows = []
for i, d in enumerate(fdates):
    # YoY = actual months still in the 12-month window + forecast months
    yoy_c = yy[d]
    sd_log = np.sqrt(var_sum[i]) / 100
    base = lv[d] / lv[d - pd.DateOffset(years=1)]
    rows.append({"date": d.strftime("%Y-%m"), "infl_mom_pct": fc[i], "mom_lo95": fc[i] - 1.96 * se[i],
                 "mom_hi95": fc[i] + 1.96 * se[i], "cpi_forecast": lv[d], "yoy_pct": yoy_c,
                 "yoy_lo95": 100 * (base * np.exp(-1.96 * sd_log) - 1),
                 "yoy_hi95": 100 * (base * np.exp(1.96 * sd_log) - 1)})
fcdf = pd.DataFrame(rows)
fcdf.to_csv("forecast.csv", index=False, float_format="%.4f")
R["forecast"] = rows
R["history_yoy"] = {d.strftime("%Y-%m"): v for d, v in df.yoy.dropna().items()}
R["history_mom"] = {d.strftime("%Y-%m"): v for d, v in df.infl.dropna().items()}
R["holdout_path"] = {"dates": [d.strftime("%Y-%m") for d in test.index], "yoy_ar": list(yoy_tr[TEST_START:].values)}
json.dump(R, open("results.json", "w"), indent=1, default=float)

print("Gap filled:", R["gap"])
print("ADF:", json.dumps(R["adf"], indent=1, default=float))
print("Holdout:", json.dumps(R["holdout"], indent=1, default=float))
print("Selection:", R["selection"])
print("Model: AR(%d), n=%d, R2=%.3f" % (P, m["n"], m["r2"]))
for c in R["model"]["coef"]:
    print("  %-9s b=%.4f se=%.4f t=%.2f p=%.4f" % (c["name"], c["b"], c["se"], c["t"], c["p"]))
print("  LB Q(12)=%.2f p=%.3f | JB=%.1f p=%.3g | max inv root=%.3f | long-run annual=%.2f%%" % (
    Q, R["model"]["ljung_box_p"], jb.statistic, jb.pvalue, R["model"]["max_inverse_root"],
    R["model"]["implied_long_run_annual"]))
print(fcdf.round(3).to_string(index=False))
print("Last actual YoY (%s): %.2f%%" % (R["last_date"], R["last_yoy"]))
