"""Generate a messy loyalty-program customer list for a 3-store US pharmacy group.

The data is simulated for portfolio purposes. A clean "true" customer base is created
first, then realistic data-entry problems are injected, the way they appear when three
store systems are exported and merged into one file.
"""
import csv
import random
from datetime import date, timedelta

random.seed(7)

FIRST = ["James", "Mary", "Robert", "Patricia", "John", "Jennifer", "Michael", "Linda", "David", "Elizabeth",
         "William", "Barbara", "Richard", "Susan", "Joseph", "Jessica", "Thomas", "Sarah", "Christopher", "Karen",
         "Daniel", "Lisa", "Matthew", "Nancy", "Anthony", "Betty", "Mark", "Sandra", "Donald", "Ashley",
         "Steven", "Kimberly", "Andrew", "Emily", "Joshua", "Donna", "Kevin", "Michelle", "Brian", "Carol",
         "Maria", "Luis", "Carlos", "Ana", "Jose", "Rosa", "Tyrone", "Keisha", "Darnell", "Aaliyah",
         "Grace", "Ethan", "Olivia", "Noah", "Ava", "Liam", "Sophia", "Mason", "Isabella", "Lucas"]
LAST = ["Smith", "Johnson", "Williams", "Brown", "Jones", "Garcia", "Miller", "Davis", "Rodriguez", "Martinez",
        "Hernandez", "Lopez", "Gonzalez", "Wilson", "Anderson", "Thomas", "Taylor", "Moore", "Jackson", "Martin",
        "Lee", "Perez", "Thompson", "White", "Harris", "Sanchez", "Clark", "Ramirez", "Lewis", "Robinson",
        "Walker", "Young", "Allen", "King", "Wright", "Scott", "Torres", "Nguyen", "Hill", "Flores",
        "Green", "Adams", "Nelson", "Baker", "Hall", "Rivera", "Campbell", "Mitchell", "Carter", "Roberts",
        "Kowalski", "Novak", "Petrovic", "Washington", "Brooks", "Reed", "Kelly", "Price", "Bennett", "Wood"]
# city, state, zip, area code
CITIES = [("Highland", "IN", "46322", "219"), ("Munster", "IN", "46321", "219"), ("Hammond", "IN", "46320", "219"),
          ("Merrillville", "IN", "46410", "219"), ("Crown Point", "IN", "46307", "219"),
          ("Schererville", "IN", "46375", "219"), ("Valparaiso", "IN", "46383", "219"),
          ("Lansing", "IL", "60438", "708"), ("Calumet City", "IL", "60409", "708"),
          ("Homewood", "IL", "60430", "708"), ("Chicago", "IL", "60617", "773")]
STORES = {"IN": ["101", "102"], "IL": ["103"]}
DOMAINS = ["example.com", "example.com", "example.net", "example.org"]  # reserved fictional domains

# ---------- clean truth ----------
customers = []
used_emails = set()
for i in range(1150):
    fn, ln = random.choice(FIRST), random.choice(LAST)
    city, st, zp, ac = random.choice(CITIES)
    store = random.choice(STORES[st]) if random.random() < .85 else random.choice(["101", "102", "103"])
    base = f"{fn}.{ln}".lower() if random.random() < .5 else f"{fn[0]}{ln}".lower()
    email = f"{base}{random.randint(1, 99) if random.random() < .6 else ''}@{random.choice(DOMAINS)}"
    while email in used_emails:
        email = f"{base}{random.randint(100, 999)}@{random.choice(DOMAINS)}"
    used_emails.add(email)
    customers.append({
        "customer_id": f"C{10001 + i}",
        "store_id": store,
        "first_name": fn, "last_name": ln,
        "email": email,
        "phone": f"{ac}5550{random.randint(100, 199)}",  # 555-0100..0199 are reserved fictional numbers
        "city": city, "state": st, "zip": zp,
        "birth_year": random.randint(1940, 2005),
        "signup_date": date(2019, 1, 1) + timedelta(days=random.randint(0, 2525)),
        "loyalty_points": random.choice([0, 0] + list(range(25, 4000, 25))),
        "sms_opt_in": "Y" if random.random() < .55 else "N",
    })

# ---------- messy rendering ----------
def mess_name(x):
    r = random.random()
    if r < .06: return x.upper()
    if r < .11: return x.lower()
    if r < .17: return f" {x}  " if random.random() < .5 else f"{x} "
    return x

PHONE_STYLES = [
    lambda p: f"({p[:3]}) {p[3:6]}-{p[6:]}", lambda p: f"({p[:3]}) {p[3:6]}-{p[6:]}",
    lambda p: f"{p[:3]}-{p[3:6]}-{p[6:]}", lambda p: f"{p[:3]}.{p[3:6]}.{p[6:]}",
    lambda p: p, lambda p: f"+1 {p[:3]}-{p[3:6]}-{p[6:]}", lambda p: f"1{p}",
]
STATE_VARIANTS = {"IN": ["IN", "IN", "IN", "Indiana", "in", "Ind.", "IN "],
                  "IL": ["IL", "IL", "IL", "Illinois", "il", "Ill.", " IL"]}
CITY_TYPOS = {"Merrillville": "Merillville", "Schererville": "Schererville ", "Valparaiso": "Valparasio",
              "Calumet City": "Calumet city", "Crown Point": "crown point"}
DATE_STYLES = [lambda d: d.isoformat(), lambda d: d.isoformat(), lambda d: d.strftime("%m/%d/%Y"),
               lambda d: f"{d.month}/{d.day}/{d.strftime('%y')}", lambda d: d.strftime("%B %d, %Y"),
               lambda d: d.strftime("%m-%d-%Y")]
EMAIL_TYPOS = {"example.com": ["exmaple.com", "example.con", "examle.com"],
               "example.net": ["exmaple.net", "example.nte"], "example.org": ["exmaple.org", "example.ogr"]}

def render(c):
    row = {"customer_id": c["customer_id"], "store_id": c["store_id"],
           "first_name": mess_name(c["first_name"]), "last_name": mess_name(c["last_name"])}
    # email
    e = c["email"]
    r = random.random()
    if r < .04:
        e = ""
    elif r < .08:
        user, dom = e.split("@")
        e = f"{user}@{random.choice(EMAIL_TYPOS[dom])}"
    elif r < .10:
        e = e.replace("@", "", 1) if random.random() < .5 else e.split("@")[0] + "@"
    elif r < .16:
        e = e.upper() if random.random() < .5 else f" {e}"
    row["email"] = e
    # phone
    p = c["phone"]
    r = random.random()
    row["phone"] = "" if r < .04 else (p[3:6] + "-" + p[6:] if r < .07 else random.choice(PHONE_STYLES)(p))
    # city / state / zip
    row["city"] = CITY_TYPOS.get(c["city"], c["city"]) if random.random() < .12 else c["city"]
    row["state"] = "" if random.random() < .03 else random.choice(STATE_VARIANTS[c["state"]])
    r = random.random()
    z = c["zip"]
    row["zip"] = ("" if r < .03 else f"{z}-{random.randint(1000, 9999)}" if r < .10
                  else f"{z}.0" if r < .15 else z[:4] if r < .18 else z)
    # birth year
    r = random.random()
    row["birth_year"] = (random.choice(["1890", "1902", "2019", "2024", "19"]) if r < .03
                         else "" if r < .06 else str(c["birth_year"]))
    # signup date
    d = c["signup_date"]
    row["signup_date"] = (d.replace(year=2052 if d.year == 2025 else d.year + 30).isoformat()
                          if random.random() < .012 else random.choice(DATE_STYLES)(d))
    # points
    pts = c["loyalty_points"]
    r = random.random()
    if r < .015:
        row["loyalty_points"] = f"-{pts or 50}"          # sign error
    elif r < .035:
        row["loyalty_points"] = ""                         # missing
    elif r < .14 and pts >= 1000:
        row["loyalty_points"] = f"{pts:,}"                 # stored as text with a comma
    else:
        row["loyalty_points"] = str(pts)
    # opt-in
    yes = c["sms_opt_in"] == "Y"
    row["sms_opt_in"] = random.choice(["Y", "Y", "Yes", "yes", "TRUE", "1"] if yes else ["N", "N", "No", "no", "FALSE", "0", ""])
    return row

rows = [render(c) for c in customers]

# exact duplicates: same record exported twice
for c in random.sample(rows, 35):
    rows.append(dict(c))
# near duplicates: same person enrolled again at another store, typed differently
next_id = 10001 + len(customers)
for c in random.sample(customers, 30):
    d = render(c)
    d["customer_id"] = f"C{next_id}"; next_id += 1
    d["store_id"] = random.choice([s for s in ["101", "102", "103"] if s != c["store_id"]])
    d["first_name"] = random.choice([c["first_name"].upper(), c["first_name"].lower(), " " + c["first_name"]])
    d["email"] = c["email"].upper() if random.random() < .5 else c["email"]
    d["signup_date"] = (c["signup_date"] + timedelta(days=random.randint(30, 400))).strftime("%m/%d/%Y")
    rows.append(d)
# a few records missing a last name (cannot be fixed, must be followed up)
for c in random.sample(rows[:1150], 6):
    c["last_name"] = ""

random.shuffle(rows)
cols = ["customer_id", "store_id", "first_name", "last_name", "email", "phone", "city", "state", "zip",
        "birth_year", "signup_date", "loyalty_points", "sms_opt_in"]
with open("loyalty_customers_raw.csv", "w", newline="") as f:
    w = csv.DictWriter(f, fieldnames=cols)
    w.writeheader()
    w.writerows(rows)
print("raw rows:", len(rows))
