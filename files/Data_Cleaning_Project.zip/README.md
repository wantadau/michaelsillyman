# Data Cleaning & Validation: Pharmacy Loyalty Customer List

**Author:** Michael Sillyman · **Tools:** LibreOffice Calc, Python
**Dataset:** simulated loyalty-program customer list for a 3-store US pharmacy group in Indiana and Illinois. Contact details use reserved fictional values (`example.com` domains, 555-01XX phone numbers), so no record can match a real person.

## The problem
Three stores exported their customer lists and merged them into one file of 1,215 rows. Before marketing could send SMS offers or finance could value outstanding loyalty points, the list needed one record per customer, usable contact details and clearly recorded consent.

## What I did
1. **Profiled the raw data** with 11 validation checks written as Calc formulas (`EXACT`, `PROPER`, `TRIM`, `COUNTIF`, `SUMPRODUCT`, `DATEVALUE`).
2. **Cleaned every field** using documented rules: names, emails, phone numbers, cities, states, ZIP codes, birth years, signup dates, points balances and SMS opt-in.
3. **Removed duplicates:** deleted 35 exact repeat rows and merged 28 customers enrolled at two stores.
4. **Logged every change** (4,275 entries) with the row, field, issue, before value, after value and action.
5. **Re-validated** the cleaned data with the same formulas, and listed records that need follow-up from staff.

## Results
| | Raw file | After cleaning |
|---|---|---|
| Rows | 1,215 | 1,152 unique customers |
| Rows passing every check | 0.2% | 82.0% |

**Rows failing each check**

| Check | Raw | Clean |
|---|---|---|
| Name | 30.8% | 0.5% |
| Email | 16.2% | 6.2% |
| Phone | 72.0% | 6.7% |
| City | 4.8% | 0.0% |
| State | 57.9% | 0.0% |
| ZIP | 17.5% | 0.0% |
| Birth year | 2.4% | 0.0% |
| Signup date | 68.1% | 1.6% |
| Points | 11.9% | 4.0% |
| SMS opt-in | 69.2% | 0.0% |
| Duplicate | 9.9% | 0.0% |

The 258 records on the follow-up list have information the file cannot supply, such as a missing email or a negative points balance, or are merged accounts whose points need confirming.

## Recommendations
- Use drop-down lists, a phone input mask and a date picker in all three store systems, so formats cannot drift apart.
- Require a last name plus an email or phone number before an enrollment saves.
- Search for existing customers by email or phone before creating a new account.
- Treat a blank SMS consent as "No" to stay compliant with US telemarketing rules (TCPA).

## Files
| File | Description |
|---|---|
| `Data_Cleaning_Report.pdf` | One-page before/after report |
| `Loyalty_Data_Cleaning.ods` | Calc workbook: summary, raw and clean data with formula checks, cleaning log, review list, rules |
| `loyalty_customers_raw.csv` | The messy merged file |
| `loyalty_customers_clean.csv` | The cleaned customer list |
| `cleaning_log.csv` | Every change made, with before and after values |
| `review_list.csv` | Records needing follow-up |
| `generate_raw_data.py`, `clean_data.py` | Scripts that create the raw data and apply the cleaning rules |

## How to reproduce
```bash
python3 generate_raw_data.py   # creates loyalty_customers_raw.csv
python3 clean_data.py          # creates the clean file, log and review list
```
Open the `.ods` workbook in LibreOffice Calc (it also opens in Excel or Google Sheets).
