"""Clean the loyalty customer list and log every change.

Outputs:
  loyalty_customers_clean.csv  - one row per customer, standardized
  cleaning_log.csv             - every change: row, field, issue, before, after, action
  review_list.csv              - records that could not be fixed automatically
"""
import csv
import re
from datetime import datetime, date
from collections import Counter

EXTRACT_DATE = date(2025, 12, 31)
CITY_ZIP = {"Highland": ("IN", "46322"), "Munster": ("IN", "46321"), "Hammond": ("IN", "46320"),
            "Merrillville": ("IN", "46410"), "Crown Point": ("IN", "46307"), "Schererville": ("IN", "46375"),
            "Valparaiso": ("IN", "46383"), "Lansing": ("IL", "60438"), "Calumet City": ("IL", "60409"),
            "Homewood": ("IL", "60430"), "Chicago": ("IL", "60617")}
CITY_FIX = {"Merillville": "Merrillville", "Valparasio": "Valparaiso"}
STATE_MAP = {"in": "IN", "ind.": "IN", "indiana": "IN", "il": "IL", "ill.": "IL", "illinois": "IL"}
DOMAIN_FIX = {"exmaple.com": "example.com", "example.con": "example.com", "examle.com": "example.com",
              "exmaple.net": "example.net", "example.nte": "example.net",
              "exmaple.org": "example.org", "example.ogr": "example.org"}
YES = {"y", "yes", "true", "1"}
NO = {"n", "no", "false", "0"}
DATE_FORMATS = ["%Y-%m-%d", "%m/%d/%Y", "%m/%d/%y", "%B %d, %Y", "%m-%d-%Y"]

log, review = [], []

def note(row_no, cid, field, issue, before, after, action):
    log.append({"raw_row": row_no, "customer_id": cid, "field": field, "issue": issue,
                "before": before, "after": after, "action": action})

def flag(rec, reason):
    rec["review_reason"] = (rec["review_reason"] + "; " if rec["review_reason"] else "") + reason

with open("loyalty_customers_raw.csv", newline="") as f:
    raw = list(csv.DictReader(f))

# ---------- Step 1: remove exact duplicate rows ----------
seen, rows = {}, []
for i, r in enumerate(raw, start=2):  # row 2 = first data row in a spreadsheet
    key = tuple(r.values())
    if key in seen:
        note(i, r["customer_id"], "(entire row)", "Exact duplicate row",
             f"same as row {seen[key]}", "removed", "Deleted")
        continue
    seen[key] = i
    r["_row"] = i
    rows.append(r)

# ---------- Step 2: standardize each field ----------
clean = []
for r in rows:
    n, cid = r["_row"], r["customer_id"]
    c = {"customer_id": cid, "store_id": r["store_id"], "review_reason": "", "merged_ids": "", "_row": n}

    for fld in ("first_name", "last_name"):
        v = r[fld]
        new = " ".join(v.split()).title()
        if new != v:
            issue = ("Extra spaces" if v.strip() != v or "  " in v else "") + \
                    (" / " if (v.strip() != v or "  " in v) and new != " ".join(v.split()) else "") + \
                    ("Inconsistent capitalization" if new != " ".join(v.split()) else "")
            note(n, cid, fld, issue, v, new, "Trimmed / Proper case")
        if not new:
            flag(c, f"Missing {fld.replace('_', ' ')}")
            note(n, cid, fld, "Missing value", "", "", "Flagged for follow-up")
        c[fld] = new

    v = r["email"]
    e = v.strip().lower().replace(" ", "")
    if e != v:
        note(n, cid, "email", "Spaces / uppercase", v, e, "Trimmed / lowercased")
    if "@" in e and e.split("@", 1)[1] in DOMAIN_FIX:
        user, dom = e.split("@", 1)
        fixed = f"{user}@{DOMAIN_FIX[dom]}"
        note(n, cid, "email", "Misspelled domain", e, fixed, "Corrected domain")
        e = fixed
    if not e:
        flag(c, "Missing email")
        note(n, cid, "email", "Missing value", "", "", "Flagged for follow-up")
    elif not re.fullmatch(r"[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,}", e):
        flag(c, "Invalid email")
        note(n, cid, "email", "Invalid format", e, "", "Cleared and flagged")
        e = ""
    c["email"] = e

    v = r["phone"]
    d = re.sub(r"\D", "", v)
    if len(d) == 11 and d.startswith("1"):
        d = d[1:]
    if len(d) == 10:
        p = f"({d[:3]}) {d[3:6]}-{d[6:]}"
        if p != v:
            note(n, cid, "phone", "Inconsistent format", v, p, "Standardized to (XXX) XXX-XXXX")
    else:
        p = ""
        flag(c, "Missing phone" if not v else "Incomplete phone")
        note(n, cid, "phone", "Missing value" if not v else "Missing area code", v, "",
             "Flagged for follow-up" if not v else "Cleared and flagged")
    c["phone"] = p

    v = r["city"]
    city = " ".join(v.split()).title()
    city = CITY_FIX.get(city, city)
    if city != v:
        note(n, cid, "city", "Misspelling" if v.strip().title() in CITY_FIX else "Spacing / capitalization",
             v, city, "Corrected")
    c["city"] = city

    v = r["state"]
    st = STATE_MAP.get(v.strip().lower(), v.strip().upper())
    if not st and city in CITY_ZIP:
        st = CITY_ZIP[city][0]
        note(n, cid, "state", "Missing value", "", st, "Inferred from city")
    elif st != v:
        note(n, cid, "state", "Inconsistent format", v, st, "Converted to 2-letter code")
    c["state"] = st

    v = r["zip"]
    z = v.strip()
    if z.endswith(".0"):
        z = z[:-2]
        note(n, cid, "zip", "Stored as decimal number", v, z, "Removed '.0'")
    elif re.fullmatch(r"\d{5}-\d{4}", z):
        z = z[:5]
        note(n, cid, "zip", "ZIP+4 format", v, z, "Kept 5-digit ZIP")
    if not re.fullmatch(r"\d{5}", z):
        if city in CITY_ZIP:
            new = CITY_ZIP[city][1]
            note(n, cid, "zip", "Missing value" if not v else "Too few digits", v, new, "Inferred from city")
            z = new
        else:
            flag(c, "Invalid ZIP")
    c["zip"] = z

    v = r["birth_year"]
    if v and v.isdigit() and 1915 <= int(v) <= 2007:
        c["birth_year"] = v
    else:
        c["birth_year"] = ""
        if v:
            note(n, cid, "birth_year", "Implausible value (must be 18+ to enroll)", v, "", "Cleared and flagged")
            flag(c, "Invalid birth year")
        else:
            note(n, cid, "birth_year", "Missing value", "", "", "Left blank (optional field)")

    v = r["signup_date"]
    parsed = None
    for fmt in DATE_FORMATS:
        try:
            parsed = datetime.strptime(v.strip(), fmt).date()
            break
        except ValueError:
            pass
    if parsed and parsed > EXTRACT_DATE:
        note(n, cid, "signup_date", "Date in the future", v, "", "Cleared and flagged")
        flag(c, "Future signup date")
        c["signup_date"] = ""
    elif parsed:
        iso = parsed.isoformat()
        if iso != v:
            note(n, cid, "signup_date", "Inconsistent date format", v, iso, "Converted to YYYY-MM-DD")
        c["signup_date"] = iso
    else:
        c["signup_date"] = ""
        flag(c, "Unreadable signup date")

    v = r["loyalty_points"]
    t = v.replace(",", "").strip()
    if not t:
        c["loyalty_points"] = ""
        flag(c, "Missing points balance")
        note(n, cid, "loyalty_points", "Missing value", "", "", "Flagged for follow-up")
    elif int(t) < 0:
        c["loyalty_points"] = ""
        flag(c, "Negative points balance")
        note(n, cid, "loyalty_points", "Negative balance", v, "", "Cleared and flagged")
    else:
        if t != v:
            note(n, cid, "loyalty_points", "Stored as text with comma", v, t, "Converted to number")
        c["loyalty_points"] = t

    v = r["sms_opt_in"]
    k = v.strip().lower()
    o = "Y" if k in YES else "N"
    if o != v:
        note(n, cid, "sms_opt_in", "Missing value" if not k else "Inconsistent coding", v, o,
             "Blank treated as N (no consent recorded)" if not k else "Recoded to Y/N")
    c["sms_opt_in"] = o
    clean.append(c)

# ---------- Step 3: merge near-duplicates (same person enrolled twice) ----------
def completeness(c):
    return sum(1 for k in ("email", "phone", "zip", "birth_year", "signup_date", "loyalty_points") if c[k])

groups = {}
for c in clean:
    key = c["email"] or f"{c['first_name']}|{c['last_name']}|{c['phone']}"
    groups.setdefault(key, []).append(c)

final = []
for key, grp in groups.items():
    if len(grp) == 1 or not key.strip("|"):
        final.extend(grp)
        continue
    grp.sort(key=lambda c: (c["signup_date"] or "9999", -completeness(c)))
    keep = dict(grp[0])
    for dup in grp[1:]:
        for fld in ("email", "phone", "zip", "birth_year", "loyalty_points"):
            if not keep[fld] and dup[fld]:
                keep[fld] = dup[fld]
        note(dup["_row"], dup["customer_id"], "(entire row)", "Duplicate customer (same person, second enrollment)",
             f"matches {keep['customer_id']}", f"merged into {keep['customer_id']}", "Merged; earliest enrollment kept")
        flag(keep, "Merged duplicate: confirm points balance")
        keep["merged_ids"] = (keep.get("merged_ids", "") + " " + dup["customer_id"]).strip()
    final.append(keep)

# Clear flags that a merge resolved (e.g. email filled from the duplicate)
for c in final:
    reasons = [x for x in c["review_reason"].split("; ") if x]
    resolved = {"Missing email": c["email"], "Missing phone": c["phone"], "Incomplete phone": c["phone"],
                "Missing points balance": c["loyalty_points"]}
    c["review_reason"] = "; ".join(x for x in reasons if not resolved.get(x))

final.sort(key=lambda c: c["customer_id"])
cols = ["customer_id", "store_id", "first_name", "last_name", "email", "phone", "city", "state", "zip",
        "birth_year", "signup_date", "loyalty_points", "sms_opt_in", "merged_ids", "review_reason"]
with open("loyalty_customers_clean.csv", "w", newline="") as f:
    w = csv.DictWriter(f, fieldnames=cols, extrasaction="ignore")
    w.writeheader(); w.writerows(final)
with open("cleaning_log.csv", "w", newline="") as f:
    w = csv.DictWriter(f, fieldnames=["raw_row", "customer_id", "field", "issue", "before", "after", "action"])
    w.writeheader(); w.writerows(sorted(log, key=lambda x: (x["raw_row"], x["field"])))
with open("review_list.csv", "w", newline="") as f:
    w = csv.DictWriter(f, fieldnames=cols, extrasaction="ignore")
    w.writeheader(); w.writerows([c for c in final if c["review_reason"]])

print("raw rows:", len(raw), "| after exact dedupe:", len(rows), "| final customers:", len(final))
print("log entries:", len(log), "| records needing review:", sum(1 for c in final if c["review_reason"]))
print(Counter(x["field"] for x in log).most_common())
print(Counter(x["action"] for x in log).most_common())
