"""Generate a synthetic US retail pharmacy sales & inventory database (SQLite) for 2025.

All data is simulated for portfolio purposes. Seasonal patterns mirror typical
US pharmacy demand: allergy products peak in spring (Apr-May) with a smaller
fall ragweed bump; cold & flu products peak in winter (Dec-Feb); sunscreen peaks in summer.
"""
import random
import sqlite3
from datetime import date, timedelta

random.seed(42)
DB = "pharmacy.db"

# name, category, unit_cost (USD), unit_price (USD), base daily demand, reorder level
PRODUCTS = [
    ("Acetaminophen 500mg 100ct", "Pain Relief", 4.50, 9.99, 7.0, 50),
    ("Ibuprofen 200mg 100ct", "Pain Relief", 4.00, 8.99, 6.0, 50),
    ("Naproxen Sodium 220mg 50ct", "Pain Relief", 4.50, 9.49, 2.5, 25),
    ("Cetirizine 10mg 30ct", "Allergy", 5.50, 14.99, 3.0, 30),
    ("Loratadine 10mg 30ct", "Allergy", 4.50, 12.99, 2.5, 30),
    ("Fluticasone Nasal Spray", "Allergy", 6.00, 17.99, 1.8, 20),
    ("Multi-Symptom Cold & Flu Liquid", "Cold & Flu", 5.00, 11.99, 2.5, 30),
    ("Cough Syrup DM 4oz", "Cold & Flu", 4.00, 9.99, 2.0, 25),
    ("Throat Lozenges 30ct", "Cold & Flu", 2.00, 4.99, 3.0, 35),
    ("Amoxicillin 500mg (Rx)", "Antibiotics", 6.00, 15.00, 2.5, 30),
    ("Azithromycin 250mg Z-Pak (Rx)", "Antibiotics", 9.00, 22.00, 1.2, 15),
    ("Lisinopril 10mg 30-day (Rx)", "Cardiovascular", 3.00, 10.00, 2.5, 30),
    ("Atorvastatin 20mg 30-day (Rx)", "Cardiovascular", 4.00, 12.00, 2.8, 30),
    ("Amlodipine 5mg 30-day (Rx)", "Cardiovascular", 3.00, 10.00, 1.8, 25),
    ("Metformin 500mg 30-day (Rx)", "Diabetes Care", 3.50, 10.00, 2.2, 30),
    ("Blood Glucose Test Strips 50ct", "Diabetes Care", 18.00, 34.99, 0.6, 10),
    ("Vitamin D3 2000 IU 100ct", "Vitamins & Supplements", 5.00, 12.99, 2.0, 25),
    ("Daily Multivitamin 90ct", "Vitamins & Supplements", 7.00, 17.99, 1.6, 20),
    ("Vitamin C + Zinc 60ct", "Vitamins & Supplements", 4.00, 10.99, 1.5, 20),
    ("Fish Oil 1000mg 100ct", "Vitamins & Supplements", 6.00, 15.99, 1.0, 15),
    ("Omeprazole 20mg 42ct", "Digestive Health", 9.00, 21.99, 1.6, 20),
    ("Antacid Chewables 96ct", "Digestive Health", 3.00, 7.49, 2.0, 25),
    ("Loperamide 2mg 24ct", "Digestive Health", 2.50, 7.99, 1.0, 15),
    ("Hand Sanitizer 8oz", "Personal Care", 1.50, 4.49, 1.0, 15),
    ("Sunscreen SPF 50 6oz", "Personal Care", 5.00, 12.99, 1.2, 15),
    ("Adhesive Bandages 30ct", "First Aid", 2.00, 5.99, 1.8, 25),
    ("Hydrocortisone Cream 1%", "First Aid", 2.50, 6.99, 1.2, 15),
    ("Digital Thermometer", "Medical Devices", 4.00, 12.99, 0.3, 10),
    ("Blood Pressure Monitor", "Medical Devices", 25.00, 49.99, 0.06, 3),
    ("Pulse Oximeter", "Medical Devices", 10.00, 24.99, 0.12, 5),
]

# Month multipliers for seasonal categories / products
SEASON = {
    "Allergy": {1: .6, 2: .8, 3: 1.3, 4: 1.8, 5: 1.9, 6: 1.4, 7: 1.0, 8: 1.1, 9: 1.3, 10: 1.0, 11: .7, 12: .6},
    "Cold & Flu": {1: 1.9, 2: 1.7, 3: 1.2, 4: .8, 5: .6, 6: .5, 7: .5, 8: .6, 9: .8, 10: 1.1, 11: 1.4, 12: 1.8},
}
PRODUCT_SEASON = {
    "Sunscreen SPF 50 6oz": {1: .3, 2: .3, 3: .6, 4: 1.0, 5: 1.6, 6: 2.2, 7: 2.4, 8: 1.8, 9: .8, 10: .4, 11: .3, 12: .3},
}
PAYMENTS = [("Credit/Debit Card", .62), ("Mobile Wallet", .20), ("Cash", .18)]

def pick_payment():
    r, acc = random.random(), 0
    for name, w in PAYMENTS:
        acc += w
        if r <= acc:
            return name
    return PAYMENTS[-1][0]

def poisson(lam):
    # Knuth's algorithm; fine for small lambda
    if lam <= 0:
        return 0
    import math
    L, k, p = math.exp(-lam), 0, 1.0
    while True:
        k += 1
        p *= random.random()
        if p <= L:
            return k - 1

con = sqlite3.connect(DB)
cur = con.cursor()
cur.executescript("""
DROP TABLE IF EXISTS sales;
DROP TABLE IF EXISTS inventory;
DROP TABLE IF EXISTS products;
CREATE TABLE products (
    product_id    INTEGER PRIMARY KEY,
    product_name  TEXT NOT NULL,
    category      TEXT NOT NULL,
    unit_cost     REAL NOT NULL,
    unit_price    REAL NOT NULL,
    reorder_level INTEGER NOT NULL
);
CREATE TABLE inventory (
    product_id        INTEGER PRIMARY KEY REFERENCES products(product_id),
    stock_on_hand     INTEGER NOT NULL,
    last_restock_date TEXT NOT NULL
);
CREATE TABLE sales (
    sale_id        INTEGER PRIMARY KEY,
    sale_date      TEXT NOT NULL,
    product_id     INTEGER NOT NULL REFERENCES products(product_id),
    quantity       INTEGER NOT NULL,
    unit_price     REAL NOT NULL,
    payment_method TEXT NOT NULL
);
""")

for i, (name, cat, cost, price, _, rl) in enumerate(PRODUCTS, 1):
    cur.execute("INSERT INTO products VALUES (?,?,?,?,?,?)", (i, name, cat, cost, price, rl))

sale_id = 1
d = date(2025, 1, 1)
while d <= date(2025, 12, 31):
    day_factor = 0.55 if d.weekday() == 6 else 1.0
    if d.month == 12:
        day_factor *= 1.1  # holiday season
    for i, (name, cat, cost, price, base, _) in enumerate(PRODUCTS, 1):
        lam = base * day_factor * SEASON.get(cat, {}).get(d.month, 1.0) * PRODUCT_SEASON.get(name, {}).get(d.month, 1.0)
        # Two deliberately slow movers in H2 to surface in the analysis
        if name in ("Digital Thermometer", "Hand Sanitizer 8oz") and d.month >= 7:
            lam *= 0.3
        n_tx = poisson(lam / 1.4)
        for _ in range(n_tx):
            qty = 1 if random.random() < .75 else random.randint(2, 3)
            # mid-year price increase of ~4% from July (cost unchanged)
            p = round(price * (1.04 if d.month >= 7 else 1.0), 2)
            cur.execute("INSERT INTO sales VALUES (?,?,?,?,?,?)",
                        (sale_id, d.isoformat(), i, qty, p, pick_payment()))
            sale_id += 1
    d += timedelta(days=1)

# Year-end stock snapshot
stock_plan = {
    "Multi-Symptom Cold & Flu Liquid": 14, "Acetaminophen 500mg 100ct": 32, "Throat Lozenges 30ct": 20,
    "Metformin 500mg 30-day (Rx)": 19, "Lisinopril 10mg 30-day (Rx)": 24, "Amoxicillin 500mg (Rx)": 27,
    "Digital Thermometer": 60, "Hand Sanitizer 8oz": 85, "Blood Pressure Monitor": 24,
    "Pulse Oximeter": 40, "Sunscreen SPF 50 6oz": 30, "Cetirizine 10mg 30ct": 45,
}
for i, (name, *_rest) in enumerate(PRODUCTS, 1):
    rl = PRODUCTS[i - 1][5]
    soh = stock_plan.get(name, rl + random.randint(5, 35))
    restock = date(2025, random.randint(8, 12), random.randint(1, 28)).isoformat()
    if name in ("Digital Thermometer", "Hand Sanitizer 8oz", "Blood Pressure Monitor", "Pulse Oximeter"):
        restock = "2025-05-14"
    cur.execute("INSERT INTO inventory VALUES (?,?,?)", (i, soh, restock))

con.commit()
print("products", cur.execute("select count(*) from products").fetchone()[0])
print("sales rows", cur.execute("select count(*) from sales").fetchone()[0])
print("units", cur.execute("select sum(quantity) from sales").fetchone()[0])
con.close()
