# Pharmacy Sales & Inventory Analysis (2025)

**Author:** Michael Sillyman · **Tools:** SQL (SQLite), LibreOffice Calc, Python
**Dataset:** simulated sales for a US retail pharmacy (15,084 transactions, 30 OTC and generic prescription products, 11 categories)

## Business question
Which products and categories drive revenue and profit, how does demand change through the year, and where is stock running short or tying up cash?

## What I did
1. **Designed a relational database** with three tables: `products`, `inventory`, `sales`.
2. **Validated the data** with SQL checks for invalid quantities and prices, orphan records and below-cost pricing (all passed).
3. **Wrote 7 analysis queries** (`analysis_queries.sql`): monthly revenue and profit, top products, category margins, slow-moving stock (days of cover), restock alerts, seasonality and payment mix.
4. **Rebuilt the summaries in LibreOffice Calc** using `SUMIFS`, `COUNTIFS`, `INDEX/MATCH` and charts, so results update when the data changes.
5. **Wrote a one-page report** with findings and recommendations.

## Key results
| Metric | Value |
|---|---|
| Revenue | $246.1K |
| Gross profit | $151.8K (61.7% margin) |
| Top category | Pain Relief, 20.3% of revenue |
| Seasonal peaks | Allergy in May (4.3× the January low); cold & flu in December (5.4× the June low) |
| Restock alerts | 6 products below reorder level, including cold & flu items in peak season |
| Cash tied up in slow stock | $1,518 across 5 items |

## Recommendations
- Build allergy inventory in February–March, ahead of the April–May peak, and cold & flu inventory from October.
- Restock the 6 alert items now, starting with cold & flu products and acetaminophen, then chronic-care prescriptions.
- Pause medical-device reorders and promote them to patients on blood pressure medication; hold sunscreen for spring.
- Review reorder levels quarterly using the days-of-cover query.

## Files
| File | Description |
|---|---|
| `Pharmacy_Sales_Analysis_Report.pdf` | One-page summary report |
| `Pharmacy_Sales_Analysis_2025.ods` | LibreOffice Calc workbook: raw data, formula-driven summaries, charts |
| `analysis_queries.sql` | All SQL queries, commented |
| `pharmacy.db` | SQLite database |
| `build_data.py` | Script that generates the simulated dataset |

## How to reproduce
```bash
python3 build_data.py                       # creates pharmacy.db
sqlite3 pharmacy.db < analysis_queries.sql  # runs every query
```
Open the `.ods` workbook in LibreOffice Calc (it also opens in Excel or Google Sheets).
