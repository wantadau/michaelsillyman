-- =====================================================================
-- Pharmacy Sales & Inventory Analysis (2025)
-- Author: Michael Sillyman
-- Database: pharmacy.db (SQLite) — tables: products, inventory, sales
-- Note: dataset is simulated for portfolio purposes.
-- =====================================================================


-- Q0. Data quality checks -------------------------------------------
-- Sales with missing or invalid values (expect 0 rows)
SELECT *
FROM sales
WHERE quantity <= 0
   OR unit_price <= 0
   OR sale_date IS NULL
   OR product_id NOT IN (SELECT product_id FROM products);

-- Products priced below cost (expect 0 rows)
SELECT product_id, product_name, unit_cost, unit_price
FROM products
WHERE unit_price <= unit_cost;


-- Q1. Monthly revenue, gross profit and transactions -----------------
SELECT strftime('%m', s.sale_date)                         AS month,
       COUNT(*)                                           AS transactions,
       SUM(s.quantity)                                    AS units_sold,
       ROUND(SUM(s.quantity * s.unit_price), 0)           AS revenue,
       ROUND(SUM(s.quantity * (s.unit_price - p.unit_cost)), 0) AS gross_profit
FROM sales s
JOIN products p ON p.product_id = s.product_id
GROUP BY month
ORDER BY month;


-- Q2. Top 10 products by revenue ------------------------------------
SELECT p.product_name,
       p.category,
       SUM(s.quantity)                                    AS units_sold,
       ROUND(SUM(s.quantity * s.unit_price), 0)           AS revenue,
       ROUND(SUM(s.quantity * (s.unit_price - p.unit_cost)), 0) AS gross_profit
FROM sales s
JOIN products p ON p.product_id = s.product_id
GROUP BY p.product_id
ORDER BY revenue DESC
LIMIT 10;


-- Q3. Revenue and margin by category --------------------------------
SELECT p.category,
       ROUND(SUM(s.quantity * s.unit_price), 0)           AS revenue,
       ROUND(SUM(s.quantity * (s.unit_price - p.unit_cost)), 0) AS gross_profit,
       ROUND(100.0 * SUM(s.quantity * (s.unit_price - p.unit_cost))
                   / SUM(s.quantity * s.unit_price), 1)   AS margin_pct,
       ROUND(100.0 * SUM(s.quantity * s.unit_price)
                   / (SELECT SUM(quantity * unit_price) FROM sales), 1) AS share_of_revenue_pct
FROM sales s
JOIN products p ON p.product_id = s.product_id
GROUP BY p.category
ORDER BY revenue DESC;


-- Q4. Slow-moving stock: days of cover based on last 90 days' sales ---
-- Days of cover = stock on hand / average daily units sold (Oct–Dec)
WITH recent AS (
    SELECT product_id, SUM(quantity) / 92.0 AS avg_daily_units
    FROM sales
    WHERE sale_date BETWEEN '2025-10-01' AND '2025-12-31'
    GROUP BY product_id
)
SELECT p.product_name,
       p.category,
       i.stock_on_hand,
       ROUND(r.avg_daily_units, 2)                        AS avg_daily_units,
       ROUND(i.stock_on_hand / NULLIF(r.avg_daily_units, 0), 0) AS days_of_cover,
       ROUND(i.stock_on_hand * p.unit_cost, 0)            AS stock_value_at_cost
FROM inventory i
JOIN products p ON p.product_id = i.product_id
LEFT JOIN recent r ON r.product_id = i.product_id
WHERE i.stock_on_hand / NULLIF(r.avg_daily_units, 0) > 90
   OR r.avg_daily_units IS NULL
ORDER BY days_of_cover DESC;


-- Q5. Restock alerts: items at or below reorder level ----------------
SELECT p.product_name,
       p.category,
       i.stock_on_hand,
       p.reorder_level,
       p.reorder_level - i.stock_on_hand                  AS shortfall
FROM inventory i
JOIN products p ON p.product_id = i.product_id
WHERE i.stock_on_hand <= p.reorder_level
ORDER BY shortfall DESC;


-- Q6. Seasonality: allergy vs cold & flu units by month --------------
SELECT strftime('%m', s.sale_date)                         AS month,
       SUM(CASE WHEN p.category = 'Allergy' THEN s.quantity ELSE 0 END) AS allergy_units,
       SUM(CASE WHEN p.category = 'Cold & Flu' THEN s.quantity ELSE 0 END) AS cold_flu_units
FROM sales s
JOIN products p ON p.product_id = s.product_id
GROUP BY month
ORDER BY month;


-- Q7. Payment method mix --------------------------------------------
SELECT payment_method,
       COUNT(*)                                           AS transactions,
       ROUND(100.0 * COUNT(*) / (SELECT COUNT(*) FROM sales), 1) AS pct_of_transactions,
       ROUND(SUM(quantity * unit_price), 0)               AS revenue
FROM sales
GROUP BY payment_method
ORDER BY transactions DESC;
