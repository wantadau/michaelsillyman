* Encoding: UTF-8.
*==============================================================================.
* Pharmacy Customer Satisfaction Survey (2025) - Statistical Analysis.
* Author:   Michael Sillyman.
* Data:     survey_data.csv (simulated survey of 640 customers, 3 US stores).
* Question: What drives customer satisfaction, and why does one store lag?
* Run:      Put this file and survey_data.csv in one folder, open this file in
*           SPSS, change the folder path in CD below, then Run > All.
*==============================================================================.

CD 'C:\path\to\project\folder'.

GET DATA
  /TYPE=TXT
  /FILE='survey_data.csv'
  /ENCODING='UTF8'
  /DELIMITERS=","
  /ARRANGEMENT=DELIMITED
  /FIRSTCASE=2
  /VARIABLES=
    resp_id F4.0
    store F1.0
    visit_type F1.0
    drive_thru F1.0
    age F2.0
    gender F1.0
    wait_min F2.0
    staff_help F1.0
    counseled F1.0
    satisfaction F2.0
    recommend F1.0.
EXECUTE.

VARIABLE LABELS
  resp_id 'Respondent ID'
  store 'Store location'
  visit_type 'Reason for visit'
  drive_thru 'Used drive-thru window'
  age 'Age in years'
  gender 'Gender'
  wait_min 'Wait time (minutes)'
  staff_help 'Staff helpfulness (1=Very poor, 5=Excellent)'
  counseled 'Pharmacist offered counseling'
  satisfaction 'Overall satisfaction (0-10)'
  recommend 'Would recommend to a friend'.

VALUE LABELS
  store 1 'Highland, IN' 2 'Merrillville, IN' 3 'Lansing, IL'
  /visit_type 0 'Front-store purchase' 1 'Prescription pickup'
  /gender 1 'Female' 2 'Male' 3 'Other / prefer not to say'
  /drive_thru counseled recommend 0 'No' 1 'Yes'.

VARIABLE LEVEL store visit_type drive_thru gender counseled recommend (NOMINAL)
  /staff_help (ORDINAL)
  /age wait_min satisfaction (SCALE).

SAVE OUTFILE='survey_data.sav'.


*------------------------------------------------------------------------------.
* 1. Descriptive statistics.
*------------------------------------------------------------------------------.
FREQUENCIES VARIABLES=store visit_type gender recommend
  /ORDER=ANALYSIS.

DESCRIPTIVES VARIABLES=age wait_min staff_help satisfaction
  /STATISTICS=MEAN STDDEV MIN MAX.


*------------------------------------------------------------------------------.
* 2. Independent-samples t-test.
*    H0: mean satisfaction is the same for prescription and front-store visits.
*    Output includes Levene's test and the equal / unequal variance rows.
*    /ES (effect size) needs SPSS 27 or later; delete that line on older versions.
*------------------------------------------------------------------------------.
T-TEST GROUPS=visit_type(1 0)
  /MISSING=ANALYSIS
  /VARIABLES=satisfaction
  /ES DISPLAY(TRUE)
  /CRITERIA=CI(.95).


*------------------------------------------------------------------------------.
* 3. One-way ANOVA with Tukey post hoc test.
*    H0: mean wait time is the same at all three stores.
*------------------------------------------------------------------------------.
ONEWAY wait_min BY store
  /STATISTICS DESCRIPTIVES HOMOGENEITY WELCH
  /MISSING ANALYSIS
  /POSTHOC=TUKEY ALPHA(0.05).

* Eta-squared for the ANOVA.
MEANS TABLES=wait_min BY store
  /CELLS=MEAN COUNT STDDEV
  /STATISTICS=ANOVA.


*------------------------------------------------------------------------------.
* 4. Chi-square test of independence.
*    H0: willingness to recommend does not depend on store.
*------------------------------------------------------------------------------.
CROSSTABS
  /TABLES=store BY recommend
  /FORMAT=AVALUE TABLES
  /STATISTICS=CHISQ PHI
  /CELLS=COUNT ROW
  /COUNT ROUND CELL.


*------------------------------------------------------------------------------.
* 5. Pearson correlations (pairwise deletion).
*------------------------------------------------------------------------------.
CORRELATIONS
  /VARIABLES=wait_min staff_help satisfaction
  /PRINT=TWOTAIL NOSIG
  /MISSING=PAIRWISE.


*------------------------------------------------------------------------------.
* 6. Multiple linear regression (listwise deletion; Highland = base store).
*    Does the store or visit-type gap remain once wait time and service
*    quality are held constant?
*------------------------------------------------------------------------------.
COMPUTE store_2 = (store = 2).
COMPUTE store_3 = (store = 3).
VARIABLE LABELS store_2 'Merrillville, IN (vs Highland)'
  /store_3 'Lansing, IL (vs Highland)'.
EXECUTE.

REGRESSION
  /MISSING LISTWISE
  /STATISTICS COEFF OUTS CI(95) R ANOVA COLLIN TOL
  /CRITERIA=PIN(.05) POUT(.10)
  /NOORIGIN
  /DEPENDENT satisfaction
  /METHOD=ENTER wait_min staff_help counseled visit_type age store_2 store_3
  /SCATTERPLOT=(*ZRESID ,*ZPRED)
  /RESIDUALS HISTOGRAM(ZRESID) NORMPROB(ZRESID).
