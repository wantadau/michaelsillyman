"""Reproduce the Stata/SPSS analyses with SciPy and NumPy, as an independent check.

Writes results.json (used by the report) and results_tables.md (readable summary).
"""
import json
import numpy as np
import pandas as pd
from scipy import stats

df = pd.read_csv("survey_data.csv")
STORES = {1: "Highland, IN", 2: "Merrillville, IN", 3: "Lansing, IL"}
R = {}
md = ["# Results (verification run, SciPy/NumPy)\n"]

# 1. Descriptives -----------------------------------------------------------
desc = df[["age", "wait_min", "staff_help", "satisfaction"]].agg(["count", "mean", "std", "min", "max"]).T
R["descriptives"] = desc.round(3).to_dict(orient="index")
R["n"] = len(df)
R["recommend_pct"] = df.recommend.mean()
R["store_n"] = df.store.value_counts().sort_index().to_dict()
md += ["## 1. Descriptive statistics", desc.round(2).to_markdown(), ""]

# 2. Independent-samples t-test: satisfaction by visit type -----------------
a = df.loc[df.visit_type == 1, "satisfaction"].dropna()
b = df.loc[df.visit_type == 0, "satisfaction"].dropna()
t_eq = stats.ttest_ind(a, b, equal_var=True)
t_w = stats.ttest_ind(a, b, equal_var=False)
lev = stats.levene(a, b, center="mean")
sp = np.sqrt(((len(a) - 1) * a.var() + (len(b) - 1) * b.var()) / (len(a) + len(b) - 2))
R["ttest"] = {"rx_mean": a.mean(), "rx_sd": a.std(), "rx_n": len(a), "otc_mean": b.mean(), "otc_sd": b.std(),
              "otc_n": len(b), "t": t_eq.statistic, "df": len(a) + len(b) - 2, "p": t_eq.pvalue,
              "welch_t": t_w.statistic, "welch_p": t_w.pvalue, "levene_F": lev.statistic, "levene_p": lev.pvalue,
              "cohens_d": (a.mean() - b.mean()) / sp}
md += ["## 2. t-test: satisfaction, prescription vs front-store", json.dumps(R["ttest"], indent=1), ""]

# 3. One-way ANOVA: wait time by store + Tukey HSD -------------------------
groups = [df.loc[df.store == s, "wait_min"] for s in (1, 2, 3)]
an = stats.f_oneway(*groups)
grand = df.wait_min.mean()
ss_b = sum(len(g) * (g.mean() - grand) ** 2 for g in groups)
ss_t = ((df.wait_min - grand) ** 2).sum()
tk = stats.tukey_hsd(*groups)
pairs = {}
for i, j in [(0, 1), (0, 2), (1, 2)]:
    pairs[f"{STORES[i+1]} vs {STORES[j+1]}"] = {"diff": groups[j].mean() - groups[i].mean(),
                                                  "p": float(tk.pvalue[i, j])}
R["anova"] = {"F": an.statistic, "df_between": 2, "df_within": len(df) - 3, "p": an.pvalue,
              "eta_sq": ss_b / ss_t,
              "means": {STORES[s]: groups[s - 1].mean() for s in (1, 2, 3)},
              "sds": {STORES[s]: groups[s - 1].std() for s in (1, 2, 3)},
              "tukey": pairs}
md += ["## 3. One-way ANOVA: wait time by store", json.dumps(R["anova"], indent=1), ""]

# 4. Chi-square: store x would recommend -----------------------------------
ct = pd.crosstab(df.store, df.recommend)
chi = stats.chi2_contingency(ct, correction=False)
n = ct.values.sum()
R["chisq"] = {"chi2": chi.statistic, "df": chi.dof, "p": chi.pvalue,
              "cramers_v": np.sqrt(chi.statistic / (n * (min(ct.shape) - 1))),
              "pct_recommend": {STORES[s]: ct.loc[s, 1] / ct.loc[s].sum() for s in (1, 2, 3)}}
md += ["## 4. Chi-square: store x recommend", ct.to_markdown(), json.dumps(R["chisq"], indent=1), ""]

# 5. Pearson correlation: wait time and satisfaction -----------------------
cc = df[["wait_min", "satisfaction", "staff_help"]].dropna()
r1 = stats.pearsonr(cc.wait_min, cc.satisfaction)
pw = df[["wait_min", "satisfaction"]].dropna()
r_pw = stats.pearsonr(pw.wait_min, pw.satisfaction)
r2 = stats.pearsonr(df[["staff_help", "satisfaction"]].dropna().staff_help,
                    df[["staff_help", "satisfaction"]].dropna().satisfaction)
R["corr"] = {"wait_sat_r": r_pw.statistic, "wait_sat_p": r_pw.pvalue, "wait_sat_n": len(pw),
             "staff_sat_r": r2.statistic, "staff_sat_p": r2.pvalue}
md += ["## 5. Pearson correlations", json.dumps(R["corr"], indent=1), ""]

# 6. Multiple regression (OLS, listwise deletion, Store 1 = base) -----------
d = df[["satisfaction", "wait_min", "staff_help", "counseled", "visit_type", "age", "store"]].dropna()
X = pd.DataFrame({
    "wait_min": d.wait_min, "staff_help": d.staff_help, "counseled": d.counseled,
    "visit_type": d.visit_type, "age": d.age,
    "store_2": (d.store == 2).astype(int), "store_3": (d.store == 3).astype(int),
})
X.insert(0, "_cons", 1.0)
y = d.satisfaction.values
Xv = X.values.astype(float)
beta, *_ = np.linalg.lstsq(Xv, y, rcond=None)
resid = y - Xv @ beta
nobs, k = Xv.shape
dfr = nobs - k
s2 = resid @ resid / dfr
se = np.sqrt(np.diag(s2 * np.linalg.inv(Xv.T @ Xv)))
tvals = beta / se
pvals = 2 * stats.t.sf(np.abs(tvals), dfr)
tcrit = stats.t.ppf(.975, dfr)
sst = ((y - y.mean()) ** 2).sum()
ssr = resid @ resid
r2 = 1 - ssr / sst
adj = 1 - (1 - r2) * (nobs - 1) / dfr
F = ((sst - ssr) / (k - 1)) / (ssr / dfr)
Fp = stats.f.sf(F, k - 1, dfr)
coef = {}
for name, bb, ss, tt, pp in zip(X.columns, beta, se, tvals, pvals):
    coef[name] = {"b": bb, "se": ss, "t": tt, "p": pp, "lo": bb - tcrit * ss, "hi": bb + tcrit * ss}
R["ols"] = {"n": nobs, "r2": r2, "adj_r2": adj, "F": F, "df_model": k - 1, "df_resid": dfr, "F_p": Fp,
            "coef": coef}
tab = pd.DataFrame(coef).T.round(4)
md += [f"## 6. OLS regression of satisfaction (N={nobs}, R2={r2:.3f}, adj R2={adj:.3f}, "
       f"F({k-1},{dfr})={F:.2f}, p={Fp:.2g})", tab.to_markdown(), ""]

json.dump(R, open("results.json", "w"), indent=1, default=float)
open("results_tables.md", "w").write("\n".join(md))
print("\n".join(md))
