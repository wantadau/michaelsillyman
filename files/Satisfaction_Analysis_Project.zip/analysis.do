*==============================================================================
* Pharmacy Customer Satisfaction Survey (2025) - Statistical Analysis
* Author:   Michael Sillyman
* Data:     survey_data.dta (simulated survey of 640 customers, 3 US stores)
* Question: What drives customer satisfaction, and why does one store lag?
* Run:      Put this file and survey_data.dta in one folder, cd to it, then
*           do analysis.do   (written for Stata 15 or later)
*==============================================================================

version 15
clear all
set more off
capture log close
log using "satisfaction_analysis.log", replace text

use "survey_data.dta", clear
describe
codebook, compact


*------------------------------------------------------------------------------
* 1. Descriptive statistics
*------------------------------------------------------------------------------
summarize age wait_min staff_help satisfaction
tabulate store
tabulate visit_type
tabulate recommend
tabstat wait_min satisfaction, by(store) statistics(mean sd n) format(%6.2f)


*------------------------------------------------------------------------------
* 2. Independent-samples t-test
*    H0: mean satisfaction is the same for prescription and front-store visits
*------------------------------------------------------------------------------
robvar satisfaction, by(visit_type)          // W0 = Levene's test for equal variances
ttest satisfaction, by(visit_type)           // pooled-variance t-test
ttest satisfaction, by(visit_type) unequal   // Welch's t-test (robustness check)
esize twosample satisfaction, by(visit_type) cohensd


*------------------------------------------------------------------------------
* 3. One-way ANOVA with Tukey post hoc test
*    H0: mean wait time is the same at all three stores
*------------------------------------------------------------------------------
oneway wait_min store, tabulate
anova wait_min store
estat esize                                  // eta-squared
pwmean wait_min, over(store) mcompare(tukey) effects


*------------------------------------------------------------------------------
* 4. Chi-square test of independence
*    H0: willingness to recommend does not depend on store
*------------------------------------------------------------------------------
tabulate store recommend, chi2 row V


*------------------------------------------------------------------------------
* 5. Pearson correlations (pairwise deletion)
*------------------------------------------------------------------------------
pwcorr wait_min staff_help satisfaction, sig obs


*------------------------------------------------------------------------------
* 6. Multiple linear regression (listwise deletion; Highland = base store)
*    Does the store or visit-type gap remain once wait time and service
*    quality are held constant?
*------------------------------------------------------------------------------
regress satisfaction wait_min staff_help i.counseled i.visit_type age i.store
estat vif                                    // multicollinearity check
estat hettest                                // Breusch-Pagan test

* Predicted satisfaction at different wait times, other variables at their means
margins, at(wait_min=(5(5)25)) atmeans

log close
