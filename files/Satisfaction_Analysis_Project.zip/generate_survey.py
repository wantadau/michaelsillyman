"""Generate a simulated customer satisfaction survey for a 3-store US pharmacy group (2025).

Outputs survey_data.csv and survey_data.dta (Stata, with variable and value labels).
"""
import numpy as np
import pandas as pd

rng = np.random.default_rng(2025)
N = 640

store = rng.choice([1, 2, 3], size=N, p=[.36, .38, .26])          # 1 Highland IN, 2 Merrillville IN, 3 Lansing IL
rx_visit = rng.binomial(1, .58, N)                                # 1 = prescription pickup, 0 = front-store purchase
age = np.clip(rng.normal(47, 16, N).round(), 18, 88).astype(int)
gender = rng.choice([1, 2, 3], size=N, p=[.55, .43, .02])          # 1 Female, 2 Male, 3 Other / prefer not to say
drive_thru = np.where(rx_visit == 1, rng.binomial(1, .30, N), 0)

# Wait time (minutes): Store 2 is understaffed; prescription pickups wait longer; drive-thru is faster
base_wait = {1: 8.5, 2: 14.0, 3: 10.0}
wait = np.array([base_wait[s] for s in store]) + 3.5 * rx_visit - 2.0 * drive_thru + rng.normal(0, 3.6, N)
wait = np.clip(wait, 1, 40).round().astype(int)

staff_help = np.clip(np.round(rng.normal(3.9, .85, N) - .25 * (store == 2)), 1, 5).astype(int)
counseled = np.where(rx_visit == 1, rng.binomial(1, .45, N), 0)

sat = (8.6 - 0.13 * wait + 0.62 * (staff_help - 3) + 0.45 * counseled
       + 0.006 * (age - 47) + rng.normal(0, 1.15, N))
satisfaction = np.clip(sat.round(), 0, 10).astype(int)
recommend = (rng.random(N) < 1 / (1 + np.exp(-(satisfaction - 6.8) * 1.1))).astype(int)

df = pd.DataFrame({
    "resp_id": np.arange(1, N + 1), "store": store, "visit_type": rx_visit, "drive_thru": drive_thru,
    "age": age, "gender": gender, "wait_min": wait, "staff_help": staff_help,
    "counseled": counseled, "satisfaction": satisfaction, "recommend": recommend,
})
# A few skipped questions, as in any real survey
for col, n in [("age", 9), ("staff_help", 6), ("satisfaction", 4)]:
    df.loc[rng.choice(N, n, replace=False), col] = np.nan

df.astype("Int64").to_csv("survey_data.csv", index=False)  # whole numbers, blanks for skipped questions

VALUE_LABELS = {
    "store": {1: "Highland, IN", 2: "Merrillville, IN", 3: "Lansing, IL"},
    "visit_type": {0: "Front-store purchase", 1: "Prescription pickup"},
    "drive_thru": {0: "No", 1: "Yes"},
    "gender": {1: "Female", 2: "Male", 3: "Other / prefer not to say"},
    "counseled": {0: "No", 1: "Yes"},
    "recommend": {0: "No", 1: "Yes"},
}
VAR_LABELS = {
    "resp_id": "Respondent ID", "store": "Store location", "visit_type": "Reason for visit",
    "drive_thru": "Used drive-thru window", "age": "Age in years", "gender": "Gender",
    "wait_min": "Wait time (minutes)", "staff_help": "Staff helpfulness (1=Very poor, 5=Excellent)",
    "counseled": "Pharmacist offered counseling", "satisfaction": "Overall satisfaction (0-10)",
    "recommend": "Would recommend to a friend",
}
dta = df.copy()
for c in ["store", "visit_type", "drive_thru", "gender", "counseled", "recommend", "wait_min", "resp_id"]:
    dta[c] = dta[c].astype("int16")
dta.to_stata("survey_data.dta", write_index=False, variable_labels=VAR_LABELS, value_labels=VALUE_LABELS,
             data_label="Pharmacy customer satisfaction survey 2025 (simulated)", version=118)
print(df.describe().round(2).T[["count", "mean", "std", "min", "max"]])
