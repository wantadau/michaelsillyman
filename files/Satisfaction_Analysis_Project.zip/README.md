# Customer Satisfaction Survey Analysis (Stata & SPSS)

**Author:** Michael Sillyman · **Tools:** Stata, SPSS
**Dataset:** simulated survey of 640 customers at a 3-store US pharmacy group (Highland IN, Merrillville IN, Lansing IL)

## Business question
Which parts of a pharmacy visit drive overall customer satisfaction, and why does the Merrillville store get fewer recommendations?

## Methods
| Analysis | Purpose |
|---|---|
| Descriptive statistics | Profile respondents, wait times and ratings |
| Independent-samples t-test | Compare satisfaction for prescription vs front-store visits |
| One-way ANOVA + Tukey HSD | Compare wait times across the three stores |
| Chi-square test of independence | Test whether willingness to recommend depends on store |
| Pearson correlation | Relate wait time and staff helpfulness to satisfaction |
| Multiple linear regression | Estimate each driver's effect with the others held constant |

## Key results
- **Wait time** is the strongest single driver: each extra minute lowers satisfaction by 0.13 points (p < .001).
- **Merrillville** customers wait 15.7 minutes on average, vs 9.9 at Highland and 11.9 at Lansing (F(2, 637) = 142.6, p < .001). Only 56% would recommend it (χ²(2) = 11.49, p = 0.003).
- In the regression (R² = 0.33), the store and visit-type differences are **not significant** once wait time and service are controlled. Merrillville's problem is its wait, not its location.
- **Staff helpfulness** (+0.58 per point) and **pharmacist counseling** (+0.48) also raise satisfaction.

## Recommendations
1. Add technician hours at Merrillville's peak times to bring its wait down to Highland's level.
2. Speed up prescription pickups with text-when-ready alerts and wider drive-thru use.
3. Offer counseling with every new prescription and include helpfulness in staff coaching.

## How to run
**Stata:** put `analysis.do` and `survey_data.dta` in one folder, `cd` to it, then run `do analysis.do`. Results are saved to `satisfaction_analysis.log`.

**SPSS:** put `analysis.sps` and `survey_data.csv` in one folder, open the syntax, set the folder path on the `CD` line, then Run > All. The script imports the CSV, applies labels and saves `survey_data.sav`. The `/ES` effect-size line in the t-test needs SPSS 27 or later.

Note: Stata's `ttest ..., by(visit_type)` subtracts group 1 from group 0, so its t is +2.34. SPSS (and the report) compare prescription minus front-store, so t = -2.34. The size and p-value are the same.

## Verification
`verify_results.py` reproduces every test independently in Python (SciPy/NumPy) and writes `results_tables.md`. The report's figures come from that run.

## Codebook
| Variable | Description | Values |
|---|---|---|
| resp_id | Respondent ID | 1–640 |
| store | Store location | 1 Highland, IN · 2 Merrillville, IN · 3 Lansing, IL |
| visit_type | Reason for visit | 0 Front-store purchase · 1 Prescription pickup |
| drive_thru | Used drive-thru window | 0 No · 1 Yes |
| age | Age in years | 18–88 (blank = skipped) |
| gender | Gender | 1 Female · 2 Male · 3 Other / prefer not to say |
| wait_min | Wait time in minutes | 1–40 |
| staff_help | Staff helpfulness | 1 Very poor – 5 Excellent (blank = skipped) |
| counseled | Pharmacist offered counseling | 0 No · 1 Yes |
| satisfaction | Overall satisfaction | 0–10 (blank = skipped) |
| recommend | Would recommend to a friend | 0 No · 1 Yes |

## Files
| File | Description |
|---|---|
| `Satisfaction_Analysis_Report.pdf` | One-page report with results and recommendations |
| `analysis.do` | Stata syntax for every analysis |
| `analysis.sps` | SPSS syntax for every analysis |
| `survey_data.dta` | Data for Stata, with variable and value labels |
| `survey_data.csv` | Data for SPSS and other tools |
| `results_tables.md` | Full results from the verification run |
| `generate_survey.py`, `verify_results.py` | Data generator and verification script |

*Data is simulated for portfolio purposes; the results show association, not proven cause.*
